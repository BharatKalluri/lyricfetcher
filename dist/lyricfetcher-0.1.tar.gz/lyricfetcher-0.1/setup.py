from setuptools import setup

setup(name='lyricfetcher',
      version='0.1',
      description='lyricfetcher',
      url='http://github.com/bharatkalluri/lyricfetcher',
      author='Bharat Kalluri',
      author_email='bharatkalluri@protonmail.com',
      license='MIT',
      packages=['lyricfetcher'],
      zip_safe=False)
