from .main import get_lyrics
